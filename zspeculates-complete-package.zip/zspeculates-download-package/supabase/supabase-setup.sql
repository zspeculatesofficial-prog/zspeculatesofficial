create table if not exists public.site_profile (
  id boolean primary key default true,
  brand text not null default 'ZSPECULATES',
  x_url text not null default 'https://x.com/z_speculates',
  youtube_url text not null default 'https://www.youtube.com/@zspeculates',
  avatar_url text not null default 'images/zspeculates-logo-light.png',
  updated_at timestamptz not null default now()
);

create table if not exists public.trades (
  id uuid primary key default gen_random_uuid(),
  week integer not null unique,
  dates text not null,
  pair text not null,
  direction text not null check (direction in ('Buy', 'Sell')),
  result text not null check (result in ('Win', 'Loss')),
  rr text not null,
  analysis jsonb not null default '[]'::jsonb,
  updated_at timestamptz not null default now()
);

insert into public.site_profile (id, brand, x_url, youtube_url, avatar_url)
values (
  true,
  'ZSPECULATES',
  'https://x.com/z_speculates',
  'https://www.youtube.com/@zspeculates',
  'images/zspeculates-logo-light.png'
)
on conflict (id) do nothing;

alter table public.site_profile enable row level security;
alter table public.trades enable row level security;

drop policy if exists "Public can read profile" on public.site_profile;
create policy "Public can read profile"
on public.site_profile for select
to anon, authenticated
using (true);

drop policy if exists "Admin can update profile" on public.site_profile;
create policy "Admin can update profile"
on public.site_profile for all
to authenticated
using (true)
with check (true);

drop policy if exists "Public can read trades" on public.trades;
create policy "Public can read trades"
on public.trades for select
to anon, authenticated
using (true);

drop policy if exists "Admin can change trades" on public.trades;
create policy "Admin can change trades"
on public.trades for all
to authenticated
using (true)
with check (true);

insert into storage.buckets (id, name, public)
values ('trade-images', 'trade-images', true)
on conflict (id) do update set public = true;

drop policy if exists "Public can read trade images" on storage.objects;
create policy "Public can read trade images"
on storage.objects for select
to anon, authenticated
using (bucket_id = 'trade-images');

drop policy if exists "Admin can upload trade images" on storage.objects;
create policy "Admin can upload trade images"
on storage.objects for insert
to authenticated
with check (bucket_id = 'trade-images');

drop policy if exists "Admin can update trade images" on storage.objects;
create policy "Admin can update trade images"
on storage.objects for update
to authenticated
using (bucket_id = 'trade-images')
with check (bucket_id = 'trade-images');

drop policy if exists "Admin can delete trade images" on storage.objects;
create policy "Admin can delete trade images"
on storage.objects for delete
to authenticated
using (bucket_id = 'trade-images');
