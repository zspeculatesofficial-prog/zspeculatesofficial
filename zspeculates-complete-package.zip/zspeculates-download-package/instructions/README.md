# ZSpeculates

Static trading track record website with a Supabase-backed admin editor.

## Open the website

Open `index.html` in a browser.

## Edit the site

1. Open the site with `?admin=1` at the end of the URL.
2. Click through to the menu.
3. Open `Admin Login`.
4. Enter your Supabase admin password.
5. Open `Manage Site`.
6. Edit the logo text, social links, and profile picture.
7. Add, edit, or delete trades.
8. Use `Export data` to save a backup JSON file.
9. Use `Import data` to restore that JSON file in another browser.

When Supabase is configured, profile edits, trades, and uploaded images save online. Until then, the site falls back to browser-only local storage.

## Supabase setup

1. Create a free Supabase project.
2. In Supabase, open `SQL Editor`.
3. Paste and run everything from `supabase-setup.sql`.
4. Go to `Authentication` > `Users`.
5. Create one user for yourself, for example `admin@zspeculates.com`, with your password.
6. Go to `Project Settings` > `API`.
7. Copy the Project URL and anon/public key.
8. Paste them into `js/supabase-config.js`.
9. Make sure `adminEmail` matches the user email you created.

The public website can read trades. Only the logged-in Supabase user can add, edit, delete trades, and upload images.

## Files

```text
index.html
css/style.css
js/trades.js
js/app.js
js/supabase-config.js
supabase-setup.sql
images/
```

`js/trades.js` holds optional starter defaults. Normal editing happens inside the website.

## Publishing

This folder can be hosted on GitHub Pages, Netlify, Vercel, Cloudflare Pages, or any static hosting service.
